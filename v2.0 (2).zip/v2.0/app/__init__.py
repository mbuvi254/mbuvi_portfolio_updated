from flask import Flask
from .miniapps import register_miniapps
from flask_mail import Mail
import os

from dotenv import load_dotenv
from maisha_chain import Blockchain

load_dotenv()

blockchain=Blockchain(2)


def create_app():
    app=Flask(__name__)
    app.secret_key=os.getenv('FLASK_SECRET_KEY')
  
    
   
    # # Flask-Mail configuration
    app.config['MAIL_SERVER'] = 'mail.cm.co.ke' 
    app.config['MAIL_PORT'] = 587                
    app.config['MAIL_USE_TLS'] = True
    app.config['MAIL_USE_SSL'] = False         
    app.config['MAIL_USERNAME'] = 'accounts@cm.co.ke'
    app.config['MAIL_PASSWORD'] = '2025Cybermaisha@'
    app.config['MAIL_DEFAULT_SENDER'] = 'mail.cm.co.ke'

    mail = Mail(app)

    #Register Miniapps  
    register_miniapps(app)



    return app