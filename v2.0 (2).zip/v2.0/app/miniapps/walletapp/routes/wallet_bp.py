from .. import wallet_bp
from flask import Blueprint,redirect,url_for,render_template,request,session,flash
from ..controllers.wallet_controller import *
from ..controllers.transaction_controller import *
import json
import datetime
from datetime import datetime






@wallet_bp.app_template_filter('timestamp')
def format_timestamp(value, fmt='%Y-%m-%d %H:%M:%S'):
    try:
        return datetime.fromtimestamp(int(value)).strftime(fmt)
    except Exception:
        return ''



@wallet_bp.route('/')
def wallet_route():
    page_title = "Wallet"
    if 'user_id' in session:
        user_id = session.get('user_id')
        user_wallets = get_user_wallets(user_id)
        
        if user_wallets is None:
            flash("Failed to load wallets. Please try again.", "danger")
            return redirect(url_for('wallet.create_wallet_route'))

        if user_wallets:
            for wallet in user_wallets:
                address=wallet['wallet_address']
                wallet_balance = get_maisha_wallet_balance(address)
                wallet['balance'] = wallet_balance['balance']

        return render_template('wallet.html', user_wallets=user_wallets, page_title=page_title)
    return redirect(url_for('user.user_login_route'))



@wallet_bp.route("/create", methods=["GET", "POST"])
def create_wallet_route():
    page_title="Create Wallet"
    user_id=session.get('user_id')
    if not user_id:
       flash("Please login first", "warning")
       return redirect(url_for('user.user_login_route'))
    
    user_id=session.get('user_id')
    wallet_types=get_wallet_types()
    if request.method == "POST":
        wallet_type=request.form.get('wallet_type')
        if wallet_type:
           new_wallet = create_maisha_wallet()
           if new_wallet:
              wallet_address=new_wallet['address']
              if save_user_wallet(user_id,wallet_type,wallet_address):
                flash(f"New wallet created: {wallet_address}", "success")
                return redirect(url_for("wallet.wallet_route"))
    return render_template('create_wallet.html',page_title=page_title,wallet_types=wallet_types)



# 📦 Wallet view route
@wallet_bp.route('/<int:wallet_id>')
def wallet_view_route(wallet_id):
    page_title = 'Wallet View'
    wallet = get_wallet(wallet_id)

    if not wallet:
        flash("Error: Wallet not found.", "danger")
        return redirect(url_for('wallet.wallet_route'))

    wallet_address = wallet['wallet_address']
    wallet_balance = get_maisha_wallet_balance(wallet_address)
    balance = wallet_balance['balance']
    transactions = get_maisha_wallet_transactions(wallet["wallet_address"])

    return render_template(
        'wallet_view.html',
        page_title=page_title,
        wallet=wallet,
        balance=balance,
        transactions=transactions
    )



#### Maisha send route
@wallet_bp.route('/send/<wallet_id>',methods=['POST','GET'])
def wallet_send_route(wallet_id):
    page_title="Send Transaction"
    wallet = get_wallet(wallet_id)
    wallet_balance=get_maisha_wallet_balance(wallet['wallet_address'])
    balance = wallet_balance['balance'] 
    if request.method == 'POST':
        sender = wallet['wallet_address']
        receiver = request.form['receiver']
        amount = float(request.form['amount'])
        if sender and receiver and amount:
            tx_status=send_maisha_transaction(sender,receiver,amount)
            if tx_status and hasattr(tx_status, 'success') and tx_status.success:
                # Store transaction result in session for display
                session['last_transaction'] = {
                    'success': True,
                    'txId': getattr(tx_status, 'txId', ''),
                    'amount': getattr(tx_status, 'amount', amount),
                    'fee': getattr(tx_status, 'fee', 0),
                    'message': getattr(tx_status, 'message', 'Transaction successful'),
                    'sender': sender,
                    'receiver': receiver,
                    'wallet_id': wallet_id
                }
                flash(f'Transaction sent successfully! TX ID: {getattr(tx_status, "txId", "")}','success')
                return redirect(url_for('wallet.transaction_status_route'))
            else:
                # Handle error case
                if hasattr(tx_status, 'error'):
                    error_msg = tx_status.error
                elif isinstance(tx_status, dict) and 'error' in tx_status:
                    error_msg = tx_status['error']
                else:
                    error_msg = 'Transaction failed'
                
                flash(error_msg, 'danger')
                session['last_transaction'] = {
                    'success': False,
                    'error': error_msg,
                    'sender': sender,
                    'receiver': receiver,
                    'amount': amount,
                    'wallet_id': wallet_id
                }
                return redirect(url_for('wallet.transaction_status_route'))
    return render_template('wallet_send.html',page_title=page_title, wallet=wallet, balance=balance)




@wallet_bp.route('/transaction/status')
def transaction_status_route():
    page_title = "Transaction Status"
    tx_status = session.get('last_transaction', None)
    session['wallet_id']=tx_status['wallet_id']
    if tx_status:
        # Clear the transaction from session after displaying
        if session.get('last_transaction', None):
           return redirect(url_for('wallet.wallet_view_route', wallet_id=session['wallet_id']))
    return render_template('tx_status.html', page_title=page_title, tx_status=tx_status)



@wallet_bp.route("/<int:wallet_id>/transactions")
def wallet_transactions(wallet_id):
    page_title = "Transactions"
    wallet = get_wallet(wallet_id)
    session['wallet_id']=wallet_id
    if not wallet:
        flash("Wallet not found", "danger")
        return redirect(url_for("wallet.wallet_route"))

    try:
        transactions = get_maisha_wallet_transactions(wallet["wallet_address"])
    except Exception as e:
        flash(str(e), "danger")
        transactions = []

    return render_template(
        "wallet_transactions.html",
        transactions=transactions,
        page_title=page_title,
        wallet=wallet
    )

@wallet_bp.route('/<tx_id>/details')
def transaction_details_route(tx_id):
    page_title="Transaction Details"
    wallet_id=session.get('wallet_id')
    maisha_transaction=get_maisha_transaction(tx_id)
    if maisha_transaction:
        return render_template('maisha_tx_details.html',page_title=page_title,maisha_transaction=maisha_transaction)
    else:
        flash('No transaction found','danger')
        return redirect(url_for('wallet.wallet_transactions',wallet_id=wallet_id))


# 💸 Receive route
@wallet_bp.route('/receive/<int:wallet_id>', methods=['GET', 'POST'])
def wallet_receive_route(wallet_id):
    page_title = "Receive"
    wallet = get_wallet(wallet_id)
    
    if not wallet:
        flash("Wallet not found", "danger")
        return redirect(url_for("wallet.wallet_route"))
    
    return render_template('wallet_receive.html',page_title=page_title,wallet=wallet)



#### Helper Functions ######
def get_wallet_balance(wallet_address):
    if wallet_address:
        try:
            balance = get_maisha_balance(wallet_address)
            return balance if balance is not None else 0.0
        except Exception as e:
            print(f"❌ Error fetching balance: {e}")
            return 0.0
    return 0.0




      