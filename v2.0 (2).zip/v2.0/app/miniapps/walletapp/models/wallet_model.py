from ..config.database import Database
from maisha_chain import Wallet,WalletDB,TransactionDB,Transaction

class WalletModel:
    def __init__(self):
        self.connection = Database().get_connection()
        self.create_user_wallets_table()
        self.create_wallet_types_table()
        self.wallet_db = WalletDB()
        self.wallet = Wallet()
        self.maisha_db=self.wallet_db.connect()
        
    def create_user_wallets_table(self):
        create_table_query = """
            CREATE TABLE IF NOT EXISTS user_wallets (
              id INT AUTO_INCREMENT PRIMARY KEY,
              user_id INT NOT NULL,
              wallet_type INT(255) NOT NULL,
              wallet_address VARCHAR(255) NOT NULL UNIQUE,
              created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
              INDEX (user_id),
              INDEX(wallet_type),
              INDEX (wallet_address)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(create_table_query)
                self.connection.commit()
                print("✅ Wallets table created/verified")
                self.seed_wallet_types()
                return True
        except Exception as e:
            print(f"❌ Error creating user wallets table: {str(e)}")
            return False
        
    
    def save_user_wallet(self,user_id,wallet_type,wallet_address):
        try:
            with self.connection.cursor() as cursor:
                qry="INSERT INTO user_wallets(user_id,wallet_type,wallet_address)VALUES(%s, %s, %s)"
                values=(user_id,wallet_type,wallet_address)
                cursor.execute(qry,values)
                self.connection.commit()
                print("✅ Wallet Saved")
                return True
        except Exception as e:
            print(f"❌ Error saving user wallet: {str(e)}")
            return False
        
        
   
    def get_wallet_by_address(self,wallet_address):
        try:
            with self.connection.cursor() as cursor:
                query = "SELECT * FROM user_wallets JOIN wallet_types ON wallet_types.id=user_wallets.wallet_type WHERE wallet_address=%s"
                values = (wallet_address,)
                cursor.execute(query, values)
                wallet = cursor.fetchone()
                return wallet
        except Exception as e:
            print(f"❌ An error occurred while retrieving user wallet: {e}")
            return None
        
    def get_all_user_wallets(self,user_id):
        try:
            with self.connection.cursor() as cursor:
                query = "SELECT * FROM user_wallets JOIN wallet_types ON wallet_types.id=user_wallets.wallet_type WHERE user_id=%s"
                values=(user_id,)
                cursor.execute(query,values)
                wallets=cursor.fetchall()
                return wallets
        except Exception as e:
            print(f"❌ An error occurred while retrieving user wallets: {e}")
            return None
        
        
    def get_wallet(self,wallet_id):
        try:
            with self.connection.cursor() as cursor:
                query = "SELECT * FROM user_wallets JOIN wallet_types ON wallet_types.id=user_wallets.wallet_type WHERE user_wallets.id=%s"
                values=(wallet_id,)
                cursor.execute(query,values)
                wallet=cursor.fetchone()
                return wallet
        except Exception as e:
            print(f"❌ n error occurred while retrieving  wallet: {e}")
            return None
            
            
    ### Wallet types ########
    def create_wallet_types_table(self):
        create_table_query = """
           CREATE TABLE IF NOT EXISTS wallet_types (
              id INT AUTO_INCREMENT PRIMARY KEY,
              name VARCHAR(50) NOT NULL UNIQUE,
              display_name VARCHAR(100) DEFAULT '',
              description TEXT DEFAULT NULL,
              is_default BOOLEAN DEFAULT FALSE,
              created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(create_table_query)
                self.connection.commit()
                print("✅ wallet_types table created/verified")
                return True
        except Exception as e:
            print(f"❌ Error creating wallet_types table: {str(e)}")
            return False
    

    def get_wallet_types(self):
        query = "SELECT * FROM wallet_types;"
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(query)
                wallet_types = cursor.fetchall()
                print("✅ Retrieved wallet types")
                return wallet_types
        except Exception as e:
            print(f"❌ Error fetching wallet types: {str(e)}")
            return []

    def seed_wallet_types(self):
        wallet_types = [
            {
                'name': 'main',
                'display_name': 'Main Wallet',
                'description': 'Primary wallet for all main operations',
                'is_default': True
            },
            {
                'name': 'savings',
                'display_name': 'Savings Wallet',
                'description': 'Wallet for saving funds',
                'is_default': False
            },
            {
                'name': 'loan',
                'display_name': 'Loan Wallet',
                'description': 'Wallet used for loan disbursement and repayment',
                'is_default': False
            }
        ]

        insert_query = """
            INSERT INTO wallet_types (name, display_name, description, is_default)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                display_name = VALUES(display_name),
                description = VALUES(description),
                is_default = VALUES(is_default);
        """

        try:
            with self.connection.cursor() as cursor:
                for wt in wallet_types:
                    cursor.execute(insert_query, (
                        wt['name'], wt['display_name'], wt['description'], wt['is_default']
                    ))
                self.connection.commit()
                print("✅ Wallet types seeded successfully")
                return True
        except Exception as e:
            print(f"❌ Error seeding wallet types: {str(e)}")
            return False




##Maisha Wallet

    
    def create_new_maisha_wallet(self)->dict:
        try:
            new_wallet=self.wallet_db.createNewWallet()
            address=new_wallet.getWalletId()
            balance=new_wallet.getBalance()
            maisha_wallet={'address':address,'balance':balance}
            return maisha_wallet
        except Exception as e:
            return {'error':str(e)}

    def get_maisha_wallet_balance(self,wallet_address)->dict:
        try:
            error=""
            balance=self.wallet_db.getWalletBalance(wallet_address,error)
            return {'balance':balance,'error':error}
        except Exception as e:
            return {'error':str(e)}

    def get_all_maisha_wallets(self):
        try:
            error=""
            wallets = self.wallet_db.getAllWallets(error)
            maisha_wallets = []
            for wallet in wallets:
                address = wallet.getWalletId()
                balance = wallet.getBalance()
                maisha_wallets.append({
                'address': address,
                'balance': balance
            })
            return maisha_wallets
        except Exception as e:
            return [{'error': str(e)}]



                