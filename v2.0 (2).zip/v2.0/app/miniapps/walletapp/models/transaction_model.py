import maisha_chain
from typing import Dict
import time
from maisha_chain import transaction_to_dict

class TransactionModel:
    def __init__(self, quiet_mode: bool = False):
        """Initialize with database connections"""
        self.transaction_db = maisha_chain.TransactionDB(quiet_mode)
        self.wallet_db = maisha_chain.WalletDB(quiet_mode)
        self.blockchain = maisha_chain.Blockchain(4)  # Default difficulty
        self.transaction = maisha_chain.Transaction()
        
        if not self.transaction_db.connect():
            raise ConnectionError("Failed to connect to TransactionDB")
        if not self.wallet_db.connect():
            raise ConnectionError("Failed to connect to WalletDB")

    def transfer_funds(self, sender: str, receiver: str, amount: float) -> Dict:
        try:
            # Use the new sendFunds function which handles all the complexity internally
            error_message = ""
            # Call the new sendFunds method
            result = self.transaction_db.sendFunds(sender, receiver, amount,error_message)
            return result
        except Exception as e:
            return {'error':str(e)}

    def get_all_transactions(self)->list:
        try:
            error=""
            transactions=self.transaction_db.getAllTransactions(error)
            if error:
                return {'error': error}
            
            maisha_transactions=[]
            for transaction in transactions:
                maisha_transactions.append(transaction_to_dict(transaction))
            return maisha_transactions
        except Exception as e:
            return {'error':str(e)}

    def get_all_transaction_pool(self)->list:
        try:
            error=""
            transactions=self.transaction_db.getTransactionsFromPool(error)
            if error:
                return {'error': error}
            
            maisha_transactions=[]
            for transaction in transactions:
                maisha_transactions.append(transaction_to_dict(transaction))
            return maisha_transactions
        except Exception as e:
            return {'error':str(e)}

    def get_transaction_by_tx_id(self, tx_id) -> dict:
        try:
            error=""
            transaction=self.transaction_db.getTransactionById(tx_id,error)
            if error:
                return {'error': error}
            
            if transaction is None:
                return {'error': f'Transaction with ID {tx_id} not found'}
            
            maisha_transaction=transaction_to_dict(transaction)
            return maisha_transaction
        except Exception as e:
            return {'error':str(e)}

    def get_all_wallet_transactions(self, wallet_address)->list:
        try:
            error=""
            transactions=self.transaction_db.getTransactionsByAddress(wallet_address,error)
            if error:
                return {'error': error}
            
            maisha_transactions=[]
            for transaction in transactions:
                maisha_transactions.append(transaction_to_dict(transaction))
            return maisha_transactions
        except Exception as e:
            return {'error':str(e)}

    def __del__(self):
        """Clean up resources"""
        if hasattr(self, 'transaction_db'):
            self.transaction_db.disconnect()
        if hasattr(self, 'wallet_db'):
            self.wallet_db.disconnect()
