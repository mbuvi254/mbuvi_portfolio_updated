from ..models.wallet_model import WalletModel

wallet_model=WalletModel()


def save_user_wallet(user_id,wallet_type,wallet_address):
    try:
        wallet_model.save_user_wallet(user_id,wallet_type,wallet_address)
        return True
    except Exception as e :
        print(f"Error saving user wallet: {str(e)}")
        return False
    
    
def get_wallet_by_user_id(user_id):
    try:
        wallet=wallet_model.get_wallet_by_user_id(user_id)
        return wallet
    except Exception as e:
        print(f"Error getting user wallet: {str(e)}")
        return None
    
    
def get_wallet_by_user_id(user_id):
    try:
        wallet=wallet_model.get_wallet_by_user_id(user_id)
        return wallet
    except Exception as e:
        print(f"rror getting user wallet: {str(e)}")
        return None
    

def get_user_wallets(user_id):
    try:
        wallets=wallet_model.get_all_user_wallets(user_id)
        return wallets
    except Exception as e:
        print(f"rror getting user wallet: {str(e)}")
        return None
    
def get_wallet(wallet_id):
    try:
        wallet=wallet_model.get_wallet(wallet_id)
        return wallet
    except Exception as e:
        print(f"Error getting user wallet: {str(e)}")
        return None

    

#Wallet Types
def get_wallet_types():
    try:
        wallet_types=wallet_model.get_wallet_types()
        return wallet_types
    except Exception as e:
        print(f"rror getting user wallet: {str(e)}")
        return None


## Maisha  Wallet
def create_maisha_wallet():
    try:
        maisha_wallet = wallet_model.create_new_maisha_wallet()
        return maisha_wallet
    except Exception as e:
        return {'error':str(e)}

def get_maisha_wallet_balance(wallet_address):
    try:
        balance = wallet_model.get_maisha_wallet_balance(wallet_address)
        return balance
    except Exception as e:
        return {'error':str(e)}


def get_maisha_wallets():
    try:
        maisha_wallets = wallet_model.get_all_maisha_wallets()
        return maisha_wallets
    except Exception as e:
        return {'error':str(e)}
    