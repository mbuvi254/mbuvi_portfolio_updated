from ..models.transaction_model import TransactionModel

transaction_model = TransactionModel()


def send_maisha_transaction(sender,receiver,amount):
    try:
        result= transaction_model.transfer_funds(sender,receiver,amount)
        if result:
            return result
    except Exception as e:
        print(f"{e}")
        return {'error':str(e)}


        


def get_maisha_transactions():
    try:
        transactions=transaction_model.get_all_transactions()
        return transactions
    except Exception as e:
        return {'error':str(e)}


def get_maisha_transaction_pool():
    try:
        transactions=transaction_model.get_all_transaction_pool()
        return transactions
    except Exception as e:
        return {'error':str(e)}

def get_maisha_transaction(tx_id):
    try:
        transaction=transaction_model.get_transaction_by_tx_id(tx_id)
        return transaction
    except Exception as e:
        return {'error':str(e)}

def get_maisha_wallet_transactions(wallet_address):
    try:
        transactions=transaction_model.get_all_wallet_transactions(wallet_address)
        return transactions
    except Exception as e:
        return {'error':str(e)}