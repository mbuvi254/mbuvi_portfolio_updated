from .userapp import user_bp
from .walletapp import wallet_bp


def register_miniapps(app):
 
    app.register_blueprint(wallet_bp)
    app.register_blueprint(user_bp)