import pymysql
import os

from dotenv import load_dotenv

load_dotenv()


class Database:
    def __init__(self):
        self.host=os.getenv('DB_HOST')
        self.user=os.getenv('DB_USER')
        self.password=os.getenv('DB_PASS')
        self.database=os.getenv('DB_MAISHA_APP')
    

    def get_connection(self):
        return pymysql.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.database,
            cursorclass=pymysql.cursors.DictCursor
        )
       