from ..config.database import Database

class UserModel:
    def __init__(self):
        self.connection = Database().get_connection()
        self.create_users_table()


    def create_users_table(self):
        try:
            with self.connection.cursor() as cursor:
                create_table = """
                    CREATE TABLE IF NOT EXISTS `users` (
                        `id` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
                        `username` varchar(255) UNIQUE NOT NULL,
                        `email` varchar(255) UNIQUE NOT NULL,
                        `registered_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                """
                cursor.execute(create_table)
                self.connection.commit()
                print(" User Table Created")
                return True
        except Exception as e:
            print(f" An error occurred while creating the users table: {e}")
            return False
        
        
    def register_user(self,username,email):
        try:
            with self.connection.cursor() as cursor:
                query = "INSERT INTO users (username, email) VALUES (%s, %s)"
                values =(username, email)
                cursor.execute(query, values)
                self.connection.commit()
                print(" User Registered")
                return True
        except Exception as e:
            print(f" An error occurred while registering the user: {e}")
            return False
            
            
    def get_user_by_id(self, id):
        try:
            with self.connection.cursor() as cursor:
                query = "SELECT * FROM users WHERE id=%s"
                values = (id,)
                cursor.execute(query, values)
                user = cursor.fetchone()
                return user
        except Exception as e:
            print(f" An error occurred while retrieving the user: {e}")
            return None
        
    def get_user_by_email(self,email):
        try:
            with self.connection.cursor() as cursor:
                query = "SELECT * FROM users WHERE email=%s"
                values = (email,)
                cursor.execute(query, values)
                user = cursor.fetchone()
                return user
        except Exception as e:
            print(f" An error occurred while retrieving the user: {e}")
            return None
        
    def get_user_by_username(self,username):
        try:
            with self.connection.cursor() as cursor:
                query = "SELECT * FROM users WHERE username=%s"
                values = (username,)
                cursor.execute(query, values)
                user = cursor.fetchone()
                return user
        except Exception as e:
            print(f" An error occurred while retrieving the user: {e}")
            return None