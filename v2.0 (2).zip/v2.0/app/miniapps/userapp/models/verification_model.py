from ..config.database import Database

class VerificationModel:
    def __init__(self):
        self.connection=Database().get_connection()
        self.create_verification_table()
        
     #User Verification Table 
    def create_verification_table(self):
        try:
            with self.connection.cursor() as cursor:
                create_table="""
                    CREATE TABLE IF NOT EXISTS user_verification (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        user_email VARCHAR(255) NOT NULL,
                        otp VARCHAR(255) NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """
                cursor.execute(create_table)
                self.connection.commit()
                print("User verification table created successfully")
                return True
        except Exception as e:
            print("Error occurred while creating user verification table: ",e)
            return False 
        
 
    
    def save_verification_otp(self,user_email,otp):
        try:
            with self.connection.cursor() as cursor:
                sql = "INSERT INTO user_verification (user_email, otp) VALUES (%s, %s)"
                values = (user_email, otp)
                cursor.execute(sql, values)
                self.connection.commit()
                print(" User verification record created successfully")
                return True
        except Exception as e:
            print("Error occurred while creating email verification record: ",e)
            return False
        

    def get_otp(self,user_email):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT otp FROM user_verification WHERE user_email=%s"
                values=(user_email,)
                cursor.execute(sql,values)
                otp = cursor.fetchone()
                return otp['otp'] if otp else None
        except Exception as e:
            print("Error occurred while fetching OTP: ",e)
            return None
        

    def delete_verification_otp(self, user_email):
        try:
            with self.connection.cursor() as cursor:
                sql = "DELETE FROM user_verification WHERE user_email=%s"
                values=(user_email,)
                cursor.execute(sql,values)
                self.connection.commit()
                print(" User verification record deleted successfully")
                return True
        except Exception as e:
            print("Error occurred while deleting email verification record: ",e)
            return False