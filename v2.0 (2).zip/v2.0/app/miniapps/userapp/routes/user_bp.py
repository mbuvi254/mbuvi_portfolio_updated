from flask import render_template, request, redirect, url_for, jsonify, session,flash
from datetime import datetime, timedelta
from ..controllers.user_controller import *
from .. import user_bp
from flask_mail import Mail,Message
import re
from flask import current_app as app
#from ...walletapp.controllers.wallet_controller import *


@user_bp.route('/')
def user_route():
    page_title = "User Home"
    if 'user_id' in session:
        return render_template('user.html', page_title=page_title)
    else:
        flash('You need to log in to access this page.', 'warning')
        return redirect(url_for('user.user_login_route'))
    

@user_bp.route('/register', methods=['POST', 'GET'])
def user_register_route():
    page_title = "Register"
    
    if request.method == 'POST':
        # Validate JSON data
        if not request.is_json:
            return jsonify({"message": "Request must be JSON"}), 400
            
        data = request.get_json()
        email = data.get('email', '').strip().lower()
        username = data.get('username', '').strip()

        # Validate required fields
        if not email or not username:
            return jsonify({"message": "Email and username are required"}), 400

        # Validate email format
        if not validate_email_format(email):
            return jsonify({"message": "Invalid email format"}), 400

        # Validate username format (alphanumeric + underscores)
        if not re.match(r'^\w{3,20}$', username):
            return jsonify({"message": "Username must be 3-20 characters (letters, numbers, _)"}), 400

        # Check for existing user
        if get_user_by_email(email):
            return jsonify({"message": "Email already exists"}), 409  # 409 Conflict
        
        if get_user_by_username(username):
            return jsonify({"message": "Username already exists"}), 409

        try:
            # Register user
            if not register_user(username, email):
                return jsonify({'error': 'Failed to register user'}), 500

            # Generate and send OTP
            otp = generate_otp()
            session['verify_email'] = email
            session['register_data'] = {  # Store for verification completion
                'username': username,
                'email': email,
                'otp_sent_at': datetime.now().isoformat()
            }

            if not save_verification_otp(email, otp):
                return jsonify({'error': 'Failed to save OTP'}), 500

            if not send_verification_email(email, otp):
                return jsonify({'error': 'Failed to send verification email'}), 500

            return jsonify({
                "message": "Verification email sent",
                "redirect_url": url_for('user.user_verify_route')
            }), 200

        except Exception as e:
            app.logger.error(f"Registration error: {str(e)}")
            return jsonify({'error': 'An unexpected error occurred'}), 500

    # GET request - render registration form
    return render_template('register.html', page_title=page_title)


# Helper function
def validate_email_format(email):
    """Basic email format validation"""
    return re.match(r'^[^@]+@[^@]+\.[^@]+$', email)

@user_bp.route('/login', methods=['POST', 'GET'])
def user_login_route():
    page_title = "Login"
    
    if request.method == 'POST':
        # Validate request content type
        if not request.is_json:
            return jsonify({"message": "Request must be JSON"}), 415
            
        data = request.get_json()
        email = data.get('email', '').strip().lower()
        
        # Validate email format and presence
        if not email:
            return jsonify({"message": "Email is required"}), 400
            
        if not re.match(r'^[^@]+@[^@]+\.[^@]+$', email):
            return jsonify({"message": "Invalid email format"}), 400
            
        # Check if user exists
        user = get_user_by_email(email)
        if not user:
            return jsonify({"message": "No account found with this email"}), 404
            
        # Clean up any existing OTP
        try:
            existing_otp = get_otp(email)
            if existing_otp and not delete_verification_otp(email):
                current_app.logger.warning(f"Failed to delete existing OTP for {email}")
        except Exception as e:
            current_app.logger.error(f"Error cleaning OTP for {email}: {str(e)}")
            
        # Generate and send new OTP
        try:
            otp = generate_otp()
            session['verify_email'] = email
            session['login_attempt'] = {  # Track login attempt
                'email': email,
                'timestamp': datetime.utcnow().isoformat(),
                'ip': request.remote_addr
            }
            
            if not save_verification_otp(email, otp):
                return jsonify({'message': 'Failed to generate verification code'}), 500
                
            if not send_verification_email(email, otp):
                return jsonify({'message': 'Failed to send verification email'}), 500
                
            return jsonify({
                "message": "Verification code sent",
                "next_step": url_for('user.user_verify_route')
            }), 200
            
        except Exception as e:
            current_app.logger.error(f"Login error for {email}: {str(e)}")
            return jsonify({'message': 'An error occurred during login'}), 500
            
    # GET request - render login page
    return render_template('login.html', 
                         page_title=page_title,
                         recaptcha_site_key=current_app.config.get('RECAPTCHA_SITE_KEY'))


@user_bp.route('/verify', methods=['POST', 'GET'])
def user_verify_route():
    page_title = "Verify"

    if request.method == 'POST':
        data = request.get_json()
        if not data:
            return jsonify({'message': 'No data provided'}), 400

        user_otp = data.get('user_otp')
        user_email = session.get('verify_email')

        # Check if email exists in session
        if not user_email:
            return jsonify({'message': 'Session expired or invalid request'}), 400

        # Check if OTP is provided
        if not user_otp:
            return jsonify({'message': 'OTP is required'}), 400

        # Fetch OTP from database
        otp = get_otp(user_email)
        if not otp:
            return jsonify({'message': 'OTP expired or not found'}), 400

        # Verify OTP
        if otp != user_otp:
            return jsonify({'message': 'Invalid OTP'}), 400

        # Delete OTP after successful verification
        if not delete_verification_otp(user_email):
            return jsonify({'message': 'Failed to clear OTP'}), 500

        # Fetch user details
        user = get_user_by_email(user_email)
        if not user:
            return jsonify({'message': 'User not found'}), 404

        # Set session variables
        session['user_id'] = user['id']
        session['username'] = user['username']
        session['user_email'] = user['email']
        
        #wallet=get_wallet_by_user_id(user['id'])
        
        # Store wallet address if available
        #if wallet:
        #    session['user_wallet'] = wallet['wallet_address']

        # Clear temporary session data
        session.pop('verify_email', None)

        return jsonify({
            'message': 'Verification successful',
            'redirect_url': url_for('wallet.wallet_route')  # Optional: Frontend can redirect
        }), 200

    # GET request: Render the verification page
    return render_template('verify.html', page_title=page_title)

@user_bp.route('/logout')
def user_logout_route():
    # Clear all session data
    session_keys = ['user_id', 'user_email', 'username', 'user_wallet', 'verify_email']
    for key in session_keys:
        session.pop(key, None)
    
    # Clear the entire session for security
    session.clear()
    
    # Clear any remember me cookies if implemented
    response = redirect(url_for('user.user_login_route'))
    
    # Optional: Add headers to prevent caching of logged-out pages
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '-1'
    
    # Flash a logout message
    flash('You have been successfully logged out.', 'success')
    
    return response

@user_bp.route('/resend-otp',methods=['GET','POST'])
def resend_otp():
    user_email = session.get('verify_email')
    if not user_email:
        return jsonify({"error": "No email found in session"}), 400
    
    old_otp = get_otp(user_email)
    if not old_otp:
        return jsonify({"error": "OTP not found"}), 404
    
    if not delete_verification_otp(user_email):
        return jsonify({"error": "Failed to delete old OTP"}), 500
    
    new_otp = generate_otp()
    if not new_otp:
        return jsonify({"error": "Failed to generate OTP"}), 500
    
    if not save_verification_otp(user_email, new_otp):
        return jsonify({"error": "Failed to save new OTP"}), 500
    
    if not send_verification_email(user_email, new_otp):
        return jsonify({"error": "Failed to send verification email"}), 500
    
    return jsonify({"message": "New OTP sent successfully"}), 200